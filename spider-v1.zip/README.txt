SPIDER V1

Files:
- index.html: complete website. No build step or dependencies required.

Run locally:
1. Open index.html in a browser.

Publish on Cloudflare Pages:
1. Open Cloudflare Dashboard -> Workers & Pages -> Create -> Pages.
2. Choose Direct Upload (or Upload assets).
3. Upload the index.html file, or upload the spider-v1.zip archive if the upload flow accepts a ZIP.
4. Deploy. Your site will be given a pages.dev address.

Notes:
- Added games are saved in the browser using localStorage. They are not shared between devices or browsers.
- Google search opens results in a new tab because Google generally blocks being embedded as a full search page.
- TikTok, Discord, YouTube, and other apps open their official sites in new tabs because many services block iframe embedding.
- Spider AI is a local demo assistant, not a live AI model. A live AI requires a secure server-side integration; do not put an API key in this public HTML file.
- Zombie Slayer is a simple click/tap game. It is included in the Games tab.
